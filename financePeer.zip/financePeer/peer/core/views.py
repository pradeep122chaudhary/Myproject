
from django.contrib import messages
from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from os import path
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, logout, login
from .models import data as jsondata
import json
from core.models import data
# Create your views here.


def logins(request):
    if not request.user.is_authenticated:
        if request.method == "POST":
            username = request.POST.get("username")
            password = request.POST.get("p")
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect("dashboard")
            else:
                return redirect("login")
        return render(request, path.join("core", 'login.html'))
    else:
        return redirect("dashboard")


def dashboard(request):
    if request.user.is_authenticated:
        return render(request, path.join("core", 'dashboard.html'))
    else:
        return redirect("login")


def create(request):
    if not request.user.is_authenticated:
        if request.method == "POST":
            username = request.POST.get('username')
            email = request.POST.get('e')
            password = request.POST.get('p')

            m = User.objects.create_user(
                username=username, email=email, password=password)
            m.save()
            return redirect('login')

        return render(request, path.join("core", 'create.html'))
    else:
        return redirect("dashboard")


def logoutss(request):
    logout(request)
    return redirect('login')


def uploaddata(request):
    if request.method == "POST":
        file = request.FILES['file']
        m = file.name.split('.')[1]
        if m != "json":
            messages.warning(request, "Invalid File Only Upload Json file")
            return redirect("uploaddata")
        else:
            df = json.load(file)

            title = []
            body = []
            userid = []

            for i in df:

                title.append(i['title'])
                body.append(i['body'])
                userid.append(i['userId'])

            for i in range(len(userid)):

                fs = jsondata(title=title[i], body=body[i], user=userid[i])
                fs.save()
            return redirect("dashboard")
        # current_user = request.user

        # title = request.POST.get("title")
        # body = request.POST.get("body")

        # fs = jsondata(title=title, body=body,userid=current_user)
        # fs.save()
        # return redirect("dashboard")

    return render(request, path.join("core", 'upload.html'))


def list(request):
    list = data.objects.all()
    return render(request, path.join("core", 'list.html'), {'list': list})
