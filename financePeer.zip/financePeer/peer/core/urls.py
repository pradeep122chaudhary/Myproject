
from django.urls import path
from .views import create, dashboard, logins, uploaddata, list
from .views import logoutss
urlpatterns = [
    path('login/', logins, name="login"),
    path('logout/', logoutss, name="logout"),
    path('create/', create, name="create"),
    path('list/', list, name="list"),
    path('upload/json', uploaddata, name="uploaddata"),
    path('', dashboard, name='dashboard'),
]
